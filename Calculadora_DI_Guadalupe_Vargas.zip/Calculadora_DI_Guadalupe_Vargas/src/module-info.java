module Calculadora_DI_Guadalupe_Vargas {
	requires java.desktop;
}